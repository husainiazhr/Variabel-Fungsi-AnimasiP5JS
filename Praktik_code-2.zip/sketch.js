let sumbuX = 0;
function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
  sumbuX++;
  rect (sumbuX, 100, 50, 20);
}